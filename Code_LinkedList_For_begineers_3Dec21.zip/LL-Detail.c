#include <stdio.h>
#include<malloc.h>

struct node
{
  int data;
  struct node *next;
};


int main()
{
    printf("Hello World");
    
    struct node *head = NULL, *temp =NULL;
    struct node *one = NULL;
    struct node *two = NULL;
    struct node *three = NULL, *four=NULL;
    struct node *point = NULL;
    int i=1;
    /* Allocate memory */
    one = malloc(sizeof(struct node));
    two = malloc(sizeof(struct node));
    three = malloc(sizeof(struct node));
    four = malloc(sizeof(struct node));
    /* Assign data values */
    one->data = 11;     two->data = 22;    three->data=33;
    four->data=44;
    
    
    /* Connect nodes */
    one->next = two;
    two->next = three;
    three->next = four;
    four->next = NULL;
    
    /* Save address of first node in head */
    head = one;     point = one;       temp = one;
    
    printf("\n First Node = %d",point->data);
    point = point->next;
    
    printf("\nSecond Node =  %d",point->data);
    point = point->next;
    
    printf("\nThird Node =  %d",point->data);   
        point = point->next;
    
    printf("\nFourth Node =  %d",point->data);    printf("\n");
    
    printf("\n");
    while(head != NULL)
{
printf("%d -->",head->data);
     head = head->next;
     
}
    
    while(temp != NULL)
{
printf("\nElemenet No= %d Elemenet Value =%d --->",i,temp->data);
     temp = temp->next;
     i=i+1;
}
    
    
        return 0;
}
