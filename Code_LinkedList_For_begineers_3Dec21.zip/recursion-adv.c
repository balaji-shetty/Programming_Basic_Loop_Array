// Online C compiler to run C online.
// Write C code in this online editor and run it.

#include <stdio.h>

void recursion(int a)
{
    if(a==0)
    return;
    else
    {
    printf("\n Inside Fun recursion a=");
    printf("%d",a);
    a=a-1;
    recursion(a);

    }
}

int main() {
    // printf() displays the string inside quotation
    printf("\n Outside Fun recursion");
    recursion(5);
    //recursion(15);
    
    return 0;
}

