#include <stdio.h>


int main() {
    int a,b,c;
    int *pa,*pb,*pc;
    pa=&a;
    pb=&b;
    pc=&c;
    a=5; b=7;  
    //*(&c) = *(&a) + *(&b);
    *pc= *pa + *pb;
    
    printf("\n Value of a is =%d",*(pa) );
    printf("\n Value of a is =%d",*(&a) );

    printf("\n Value of b is =%d",*(pb) );
    printf("\n Value of b is =%d",*(&b) );
    
    printf("\n Value of C is =%d",c);
    return 0;
}
//*(At the address)
//Value of a =*(&a)
// a = *(&a)
// a = *(pa)