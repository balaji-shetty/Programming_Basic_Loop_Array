#include <iostream>
using namespace std;


int main ()
{
  int z;
  int add(int a, int b);
  int sub(int a, int b);
  int mul(int a, int b);
  int divi(int a, int b);

  
  z=5+3;
  
  int fun_add = add(5,3);
  int fun_sub = sub(5,3);
  int fun_mul = mul(5,3);
  int fun_div = divi(5,3);
  
  
  cout << "The result is " << z;
  
  cout << "\n Addition Result is " << fun_add;
  cout << "\n SUbtraction Result is " << fun_sub;
  cout << "\n Multiplication Result is " << fun_mul;
  cout << "\n Division Result is " << fun_div;
  
  
}

int add(int a, int b)
{
  int r;
  r=a+b;
  return r;
}


int sub(int a, int b)
{
  int r;
  r=a-b;
  return r;
}



int mul(int a, int b)
{
  int r;
  r=a*b;
  return r;
}



int divi(int a, int b)
{
  int r;
  r=a/b;
  return r;
}

//z = addition (5,3);