#include <stdio.h>


int main() {
    int rn[] = {2,4,6,8,99};
    int *prn;
    prn = &rn[0];
    
    printf("\n Value of Roll no is =%d",*(prn) );
    ++prn;
    printf("\n Value of Roll no is =%d",*(prn) );
    ++prn;
    printf("\n Value of Roll no is =%d",*(prn) );
    ++prn;
    printf("\n Value of Roll no is =%d",*(prn) );
    ++prn;
    printf("\n Value of Roll no is =%d",*(prn) );
    
    
    return 0;
}
//*(At the address)
//Value of a =*(&a)
// a = *(&a)
// a = *(pa)