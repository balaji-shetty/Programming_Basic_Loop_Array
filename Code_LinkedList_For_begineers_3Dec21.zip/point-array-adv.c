#include <stdio.h>
#include<malloc.h>

int main() {
    // int rn[] = {2,4,6,8,99};
    int *rn,*base;
    int i,sum=0;

    rn=(int*)malloc(5*sizeof(int));
    base=rn;
    
    
    for(i=0;i<5;++i)
    {
        printf("\nEnter Array Elemenets=");
        scanf("%d",rn);
        rn = rn + 1;
    }
    for(i=0;i<5;++i)
    {
        printf("\n Array Elemenets=%d",base[i]);
    }
    return 0;
}
//*(At the address)
//Value of a =*(&a)
// a = *(&a)
// a = *(pa)